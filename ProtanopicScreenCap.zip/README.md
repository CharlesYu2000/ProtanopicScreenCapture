ProtanopicScreenCapture 

Authors: Brandon, Charles, Andrew

To run this program, double click on the ProtanopicScreenCapture.jar file. A
new window will open with the instructions. To take a color adjusted screenshot,
press 'F6' and the window will display the modified screenshot. The screenshot
is saved to the MyScreenshots folder. To quit, press 'Q'.

